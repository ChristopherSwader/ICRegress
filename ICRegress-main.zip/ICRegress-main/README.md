# ICRegress
Interpretable Configurational Regression

Interpretable Configurational Regression (ICR) uses a Machine Learning (genetic optimization) algorithm in order to separate the overall sample into different model-specific subgroups. It thus allows for a more case-sensitive assignment of cases to models within the regression paradigm.

Read the vignette for a full description on the method and package. Feedback is welcome. 
